package Cy.mod.glq.ui.component

import androidx.compose.runtime.Composable
import Cy.mod.glq.Natives

@Composable
fun KsuIsValid(
    content: @Composable () -> Unit
) {
    val isManager = Natives.isManager
    val ksuVersion = if (isManager) Natives.version else null

    if (ksuVersion != null) {
        content()
    }
}
