package Cy.mod.glq.data.repository

import Cy.mod.glq.data.model.Module
import Cy.mod.glq.data.model.ModuleUpdateInfo

interface ModuleRepository {
    suspend fun getModules(): Result<List<Module>>
    suspend fun checkUpdate(module: Module): Result<ModuleUpdateInfo>
}
