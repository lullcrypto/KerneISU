package Cy.mod.glq.ui.component.uninstalldialog

import androidx.compose.runtime.Composable
import Cy.mod.glq.ui.LocalUiMode
import Cy.mod.glq.ui.UiMode

@Composable
fun UninstallDialog(
    show: Boolean,
    onDismissRequest: () -> Unit
) {
    when (LocalUiMode.current) {
        UiMode.Miuix -> UninstallDialogMiuix(show, onDismissRequest)
        UiMode.Material -> UninstallDialogMaterial(show, onDismissRequest)
    }
}
