// Mirrored from compose-miuix-ui example.

package Cy.mod.glq.ui.component.miuix.effect

enum class DeviceType {
    PHONE,
    PAD,
}
