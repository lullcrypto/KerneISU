package Cy.mod.glq.ui.component

enum class WarningLevel { Error, Notice }
