package Cy.mod.glq.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class ModuleUpdateInfo(
    val downloadUrl: String,
    val version: String,
    val changelog: String,
    val versionCode: Int = 0,
) {
    companion object {
        val Empty = ModuleUpdateInfo("", "", "")
    }
}
